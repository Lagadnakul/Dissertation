"""
DAY 2 - STEP 2
Purpose: Pull ONE real coding task from SWE-bench Lite and look at it.
This is the kind of task your agent will eventually try to solve.
No cost. Public dataset.
"""

from datasets import load_dataset

# Downloads the SWE-bench Lite test set (small, ~300 tasks)
dataset = load_dataset("princeton-nlp/SWE-bench_Lite", split="test")

# Just look at the very first task
task = dataset[0]

print("=" * 60)
print("TASK ID:", task["instance_id"])
print("REPO:", task["repo"])
print("-" * 60)
print("PROBLEM STATEMENT (the bug report):")
print(task["problem_statement"][:1000], "...")  # first 1000 characters only
print("=" * 60)
print("This is what a real SWE-bench Lite task looks like.")
print("Total tasks available:", len(dataset))
