"""
DAY 2 - STEP 1
Purpose: Confirm your free Gemini API key actually works.
No cost. Uses the free tier.
"""

import google.generativeai as genai

# STEP A: Paste your API key between the quotes below.
# (Get it from https://aistudio.google.com -> "Get API key")
API_KEY = "PASTE_YOUR_KEY_HERE"

genai.configure(api_key=API_KEY)

# Free-tier model
model = genai.GenerativeModel("gemini-2.5-flash")

response = model.generate_content(
    "Say hello and confirm you are working, in one short sentence."
)

print("=" * 50)
print("MODEL RESPONSE:")
print(response.text)
print("=" * 50)
print("If you see a sentence above, your API key works. You're done with Step 1.")
